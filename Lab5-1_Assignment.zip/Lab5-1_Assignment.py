# -------------------------------------------------- #
# Title: Lab 5-1
# Description: Writing and Reading Data from a file
# ChangeLog (Who,When,What): Joel Quispe, 2/17/2022, added parts to make the program work
# RRoot,1.1.2030,Created started script
# Joel Quispe, 2/17/2022, Added read/write to file code
# -------------------------------------------------- #

# Declare my variables
strChoice = ''  # User input
lstRow = []  # list of data
strFile = 'HomeInventory.txt'  # data storage file
objFile = None  # file handle

# Get user Input
while (True):
    print("Write or Read file data, then type 'Exit' to quit!")
    strChoice = input("Choose to [W]rite or [R]ead data: ")

    # Process the data
    if (strChoice.lower() == 'exit'):
        break

    elif (strChoice.lower() == 'w'):
        # List to File
        Inventory = ['HouseItem', 'HouseItemValue']
        HouseItem = str(input('enter household item: '))
        HouseItemValue = input('enter household value in dollars: ')
        objFile = open("HomeInventory.txt", "a")
        objFile.write(HouseItem + "," + HouseItemValue + "\n")
        objFile.close()

        # for row in lstRow:
        # print (row[0])
        # objFile.write((row[0]) + "," + (row[1]) + "\n")
        # objFile.write(lstRow, "\n")
        # objFile.close()
        # print('ToDo: add code here')



    elif (strChoice.lower() == 'r'):
        # File to List
        objfile = open(strFile, "r")
        for row in objfile:
            # lstRow = row.split(",")
            # print((row).strip())
            print(row)
        # print('ToDo: add code here')
    else:
        print('Please choose either W or R!')
